# Example InSpec Profile

This example shows the implementation of an InSpec [profile](../../docs/profiles.rst).
